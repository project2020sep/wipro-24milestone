package com.gl.exercise.item.beans;
public enum ItemStatus{
    AVAILABLE,
    SOLD
}