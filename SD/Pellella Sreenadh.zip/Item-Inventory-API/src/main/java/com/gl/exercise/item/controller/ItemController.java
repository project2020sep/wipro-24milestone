package com.gl.exercise.item.controller;

import java.util.Optional;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.*;
import org.springframework.data.domain.Page;

import com.gl.exercise.item.beans.Item;
import com.gl.exercise.item.service.ItemService;

@RestController
@RequestMapping("/app/item")
public class ItemController {

    @Autowired
    ItemService itemService;

    @PostMapping
    ResponseEntity<Item> addItem(@RequestBody Item item) {
        if(itemService.getById(item.getItemId().isPresent())) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
        item.setItemEnteredDate(LocalDate.now());
        item.setItemLastModifiedDate(LocalDate.now());
        Item savedItem = itemService.add(item);
        return new ResponseEntity<>(savedItem , HttpStatus.CREATED);
    }

    @PutMapping("/{itemId}")
    public ResponseEntity<Item> updateItem(@PathVariable Integer itemId, @RequestBody Item item) {
        Item updatedItem = itemService.update(itemId , item);
        if(updatedItem != null) {
            return new ResponseEntity<>(updatedItem , HttpStatus.OK);
        }else {
            return new ResponseEntity<>(HttpStatus.NOT_Found);
        }
    }

    @DeleteMapping("/{itemId}")
    public ResponseEntity<Void> deleteItem(@PathVariable Integer itemId) {
        if(itemService.getById(itemId).isPresent()){
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
        itemService.deleteById(itemId);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @DeleteMapping
    public ResponseEntity<Void> deleteAllItems() {
        itemService.deleteAll();
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @GetMapping("/{itemId}")
    public ResponseEntity<Item> getItem(@PathVariable Integer itemId) {
        Optional<Item> item = itemService.getById(itemId);
        return item.map(value -> new ResponseEntity<>(value , HttpStatus.OK)).orEsleGet(() -> new ResponseEntity<>(HttpStatus.NOT_Found));
    }

    @GetMapping
    Public List<Item> getAllItems() {
        List<Item> items = itemService.getAll();
        return items;
    }

    @GetMapping(params = {"itemStatus", "itemEnteredByUser"})
    public ResponseEntity<List<Item>> getItemsByStatusAndUser(@RequestParam String status, @RequestParam String itemEnteredByUser) {
        List<Item> items = itemService.getByStatusAndItemEnteredByUserName(itemStatus, itemEnteredByUser);
        return new ResponseEntity<>(items, HttpStatus.OK);
    }

    @GetMapping(params = {"pageSize", "page", "sortBy"})
    public ResponseEntity<Page<Item>> getPagedAndSortedItems(@RequestParam int pageSize, @RequestParam int page, @RequestParam String sortBy) {
        Page<Item> itemPage = itemService.getItemsSortedBySellPrice(page, pageSize);
        return new ResponseEntity<>(itemPage, HttpStatus.OK);
    }
		
}
