package com.gl.exercise.item.repo;

import com.gl.exercise.item.beans.item;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface itmeRepository extend JpaRepository<item, integer>{
    list<item>findByItemStatusAndItemEnteredByUser(String itemStatus, String itemEnteredByUser);

}
	

