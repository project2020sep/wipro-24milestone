package com.example.inventory.model;

import javax.persistence.*;

import java.time.LocalDateTime;

@Entity
public class Item {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private Long itemId;
    private String itemName;
    private String itemEnterByUser;
    private LocalDateTime itemEnterDte;
    private double itemBuyingPrice;
    private double itemSellingPrice;
    private LocalDateTime itemLastModifiesDte;
    private String itemLastModifiedByUser;

    @Enumerated(EnumType.STRING)
    private ItemStatus itemStatus;
    // Getter and Setter
}
enum ItemStatus {
    AVAILABLE'
    SOLD
}
	
	

