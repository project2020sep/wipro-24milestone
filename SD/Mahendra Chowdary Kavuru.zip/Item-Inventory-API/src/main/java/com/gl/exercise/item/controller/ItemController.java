package com.gl.exercise.item.controller;

import java.util.Optional;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestParam;

import com.gl.exercise.item.beans.Item;
import com.gl.exercise.item.service.ItemService;

@RestController
@RequestMapping("/app/item")
public class ItemController {
    @Autowired
    private ItemService itemService;

    @PostMapping
    public ResponseEntity<Item>addItem(@RequestBody Item item){
        try{
            Item addedItem=itemService.add(item);
            return new ResponseEntity<>(addedItem,HttpStatus.CREATED);
        }catch(RuntimeException e){
        return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("/{itemId}")
    public ResponseEntity<Item> updatedItem(@PathVariable int itemId,@RequestBody Item item){
        try{
            item.setItemId());
            Item updateItem=itemService.updated(item);
            return new ResponseEntity<>(updatedItem,HttpStatus.OK);
        }catch(RuntimeException e){
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{itemId}")
    public ResponseEntity<void> deleteItem(@PathVariable int itemId){
        try{
            itemService.deleteById(itemId);
            return new ResponseEntity<>(HttpStatus.Ok);
        }catch (RuntimeException e){
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    @DeleteMapping
    public ResponseEntity<void> deleteALLItems(){
        itemService.deleteAll();
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @GetMapping("/{itemId}")
    public ResponseEntity<Item> getItemById(@PathVariable int itemId){
        try{
            Item item=itemService.getById(itemId);
            return new ResponseEntity<>(item,HttpStatus.OK);
        } catch (RuntimeException e){
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping
    public ResponseEntity<List<Item>> getAllItems(
        @RequestParam(required=false)String itemStatus,
        @RequestParam(required=false)String itemEnteredByUser,
        @RequestParam(required=false)Integer pageSize,
        @RequestParam(required=false)Integer page,
        @RequestParam(required=false)String sortBy){
    if (itemStatus!=null && itemEnteredByUser!=null){
        return new ResponseEntity<>(itemService.getByStatusAndItemEnteredByUserName(itemStatus,itemEnteredByUser).HttpStatus.OK);
    }
    if(pageSize!=null && page!=null && sortBy!=null){
        return new ResponseEntity<>(itemService.getItemsSortedBySellPrice(page,pageSize,sortBy).getContent(),HttpStatus.OK);
    }
    return new ResponseEntity<>(itemService.getAll(),HttpStatus.OK);
        }



		
}
