package com.gl.exercise.item.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gl.exercise.item.beans.Item;
import com.gl.exercise.item.beans.ItemStatus;
import com.gl.exercise.item.service.ItemService;

@RestController
@RequestMapping("/app/item")
public class ItemController {

    @Autowired
    private ItemService itemService;

    @PostMapping
    public ResponseEntity<Item> createItem(@RequestBody Item item)
{
    if (item.getItemId() != null && itemService.getItemById(item.getItemId()).isPresent()){
        return ResponseEntity.status(400).build();
    }
    Item createItem =itemService.createItem(item);
    return ResponseEntity.status(201).body(createItem);
    }

@PutMapping("/{itemId}")
public ResponseEntity<Item> updateItem(@PathVariable Long itemId  ,  @RequestBody Item item)
{
    Optional<Item> updatedItem = itemService.updatedItem(itenId, item);
    return updatedItem.map(value -> ResponseEntity.ok().body(value)).orElseGet(() -> ResponseEntity.status(404).build());
}

@DeleteMapping("/{itemId}")
public ResponseEntity<void> deleteItems(@PathVariable Long itemId){
   boolean deleted = itemService.deleteItems(itemId);
    return deleted ? ResponseEntity.ok().build() : ResponseEntity.status(400).build();
}


@DeleteMapping
public ResponseEntity<void> deleteAllItems(){
    itemService.deleteAllItems();
    return ResponseEntity.ok().build();
}

@GetMapping("/{itemId}")
public ResponseEntity<Item> getItemById(@PathVariable Long itemId  )
{
    Optional<Item> Item = itemService.getItemById(itenId );
    return item.map(value -> ResponseEntity.ok().body(value)).orElseGet(() -> ResponseEntity.status(404).build());
}

@GetMapping
public ResponseEntity<List<Item>> getAllItems(){
    List<Item> items = itemService.getAllItems();
        return ResponseEntity.ok().body(items);
}

@GetMapping(params = {"itemStatus", "itemEnteredByUser"})
public ResponseEntity<List<Item>> getItemsByStatusAndUser(@RequestParam ItemStatus itemStatus,
   
    @RequestParam String itemEnteredByUser){

        List<Item> items = itemService.getItemsByStatusAndUser(pageSize, itemEnteredByUser);
        return ResponseEntity.ok().body(items);
    }
@GetMapping(params = {"pageSize" , "page", "sortBy"})	

    public ResponseEntity<List<Item>> getItemsPaginated(@RequestParam int pagesize,
    @RequestParam int page,
    @RequestParam String sortBy){

        List<Item> items = itemService.getItemsPaginated(pageSize, page, sortBy);
        return ResponseEntity.ok().body(items);
    }

}
