package com.gl.exercise.item;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gl.exercise.item.beans.Item;
import com.gl.exercise.item.controller.ItemController;
import com.gl.exercise.item.service.ItemService;

import ch.qos.logback.core.recovery.ResilientFileOutputStream;

@WebMvcTest(ItemController.class)
@AutoConfigureMockMvc
@ActiveProfiles("test")
public class ControllerTests {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private ItemService itemService;

    private List<Item> mockItems;
	
	@BeforeEach
    public void setup() {
        // Initialize mock data
		mockItems = new ArrayList<>();
		mockItems.add(new Item(1, "item 1", "user 1", LocalDate.of(2024, 8, 2), 100, 120, LocalDate.of(2024, 8, 3), "user 1", "available"));
		mockItems.add(new Item(2, "item 2", "user 1", LocalDate.of(2024, 8, 2), 100, 120, LocalDate.of(2024, 8, 3), "user 1", "available"));
		mockItems.add(new Item(3, "item 3", "user 2", LocalDate.of(2024, 8, 2), 100, 120, LocalDate.of(2024, 8, 3), "user 1", "available"));
		mockItems.add(new Item(4, "item 4", "user 2", LocalDate.of(2024, 8, 2), 100, 120, LocalDate.of(2024, 8, 3), "user 1", "available"));
		mockItems.add(new Item(5, "item 5", "user 1", LocalDate.of(2024, 8, 2), 100, 120, LocalDate.of(2024, 8, 3), "user 1", "available"));
		mockItems.add(new Item(6, "item 6", "user 2", LocalDate.of(2024, 8, 2), 100, 120, LocalDate.of(2024, 8, 3), "user 1", "available"));

    }

	@Test
    public void testAdd() throws JsonProcessingException, Exception {
        int id = 1;
        Item item = new Item(1, "item 1", "user 1", LocalDate.of(2024, 8, 2), 100, 120, LocalDate.of(2024, 8, 3), "user 1", "available");

        when(itemService.add(any(Item.class))).thenReturn(item);

     // Perform the POST request
        mockMvc.perform(MockMvcRequestBuilders.post("/app/item")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(item)))
                .andExpect(MockMvcResultMatchers.status().isCreated())
                .andReturn();
    }
	
	@Test
    public void testUpdate() throws JsonProcessingException, Exception {
		int id = 1;
        Item item = new Item(1, "item 1", "user 1", LocalDate.of(2024, 8, 2), 100, 120, LocalDate.of(2024, 8, 3), "user 1", "available");

        when(itemService.update(any(Item.class))).thenReturn(item);

     // Perform the POST request
        mockMvc.perform(MockMvcRequestBuilders.put("/app/item/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(item)))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andReturn();
    }
    
	@Test
    public void testGetById() throws JsonProcessingException, Exception {
		int id = 1;
        Item item = new Item(1, "item 1", "user 1", LocalDate.of(2024, 8, 2), 100, 120, LocalDate.of(2024, 8, 3), "user 1", "available");

        when(itemService.update(any(Item.class))).thenReturn(item);

     // Perform the POST request
        mockMvc.perform(MockMvcRequestBuilders.put("/app/item/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(item)))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andReturn();
    }
	
}
