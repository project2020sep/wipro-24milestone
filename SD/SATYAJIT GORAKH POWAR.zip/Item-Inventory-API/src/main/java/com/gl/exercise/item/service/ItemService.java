package com.gl.exercise.item.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.gl.exercise.item.beans.Item;
import com.gl.exercise.item.repo.ItemRepo;

@Service
public class ItemService {


    @Autowired
    private ItemRepository itemRepository;

    public Item addItem(Item item) {
        item.setItemEnteredDate(LocalDateTime.now());
        item.setItemLastModifiedDate(LocalDateTime.now());
        return itemRepository.save(item);
    }

    public Optional<Item> updateItem(Long itemId, Item itemDetails) {
        return itemRepository.findById(itemId).map(item -> {
            item.setItemName(itemDetails.getItemName());
            item.setItemBuyingPrice(itemDetails.getItemBuyingPrice());
            item.setItemSellingPrice(itemDetails.getItemSellingPrice());
            item.setItemLastModifiedDate(LocalDateTime.now());
            item.setItemLastModifiedByUser(itemDetails.getItemLastModifiedByUser());
            item.setItemStatus(itemDetails.getItemStatus());
            return itemRepository.save(item);
        });
    }

    public boolean deleteItem(Long itemId) {
        if (itemRepository.existsById(itemId)) {
            itemRepository.deleteById(itemId);
            return true;
        }
        return false;
    }

    public void deleteAllItems() {
        itemRepository.deleteAll();
    }

    public Optional<Item> getItemById(Long itemId) {
        return itemRepository.findById(itemId);
    }

    public List<Item> getAllItems() {
        return itemRepository.findAll();
    }

    public List<Item> getItemsByStatusAndEnteredByUser(Item.ItemStatus status, String enteredByUser) {
        return itemRepository.findByItemStatusAndItemEnteredByUser(status, enteredByUser);
    }

    public List<Item> getItemsPaginated(int pageSize, int page, String sortBy) {
        return itemRepository.findAll(PageRequest.of(page, pageSize, Sort.by(sortBy))).getContent();
    }
}








