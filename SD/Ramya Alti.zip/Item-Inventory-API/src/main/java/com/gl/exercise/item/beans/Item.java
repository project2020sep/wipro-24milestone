package com.gl.exercise.item.beans;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Item {
    @Id
    @GeneratedValues(strategy= GenerationType.IDENTITY)
    private Integer itemId;

    @Coulmn(nullble=false)
    private String itemName;
    @Column(nullble=false, updatable=false)
    private String itemEnteredByUser;

    @Column(nullble=false, updatable=false)
    private LocalDateTime itemEnteredDate;
    @Coulmn(nullble=false)
    private Double itemBuyingPrice;

    @Coulmn(nullble=false)
    private Double itemSellingPrice;

    @Coulmn(nullble=false)
    private LocalDateTime itemLastModifiedDate;

    @Coulmn(nullble=false)
    private String itemLastModifiedByUser;

    @Enumerated(EnumType.String)
    @Coulmn(nullble=false)
    private itemStatus itemStatus;
     
    @PrePersist
    protected void onCreate(){
        itemEnteredDate=LocalDateTime.now();
        itemLastModifiedDate=LocalDateTime.now();
    }
    @PreUpdate
    protected void onUpdate(){
        itemLastModifiedDate=LocalDateTime.now();
    }

    //Getters and Setters
    public Integer getItemId(){
        return itemId;
    }
    public void setItemId(Integer itemId){
        this.itemId=itemId;
    }
    public String getItemName(){
    return itemName;
    }
    public void setItemName(String itemName){
        this.itemName=itemName;
    }

    public String getItemEnteredByUser(){
        return itemEnteredByUser;
    }
    public void setItemEnteredByUser(String itemEnteredByUser){
        this.itemEnteredByUser=itemEnteredByUser;
    }

    public LocalDateTime getitemEnteredDate(){
        return itemEnteredDate;
    }
    public void setitemEnteredDate(LocalDateTime itemEnteredDate){
        this.itemEnteredDate=itemEnteredDate;

    }
    public Double getitemBuyingPrice(){
        return itemBuyingPrice;
    }
    public void setItemBuyingPrice(Double itemBuyingPrice){
        this.itemBuyingPrice=itemBuyingPrice;
    }
    public Double getitemSellingPrice(){
        return itemSellingPrice;
    }
    public void setItemSellingPrice(Double itemSellingPrice){
        this.itemSellingPrice=itemSellingPrice;
    }
    public LocalDateTime getitemLastModifiedDate(){
        return itemLastModifiedDate;
    }
    public void setItemLatModifiedDate(LocalDateTime itemLastModifiedDate){
        this.itemLastModifiedDate=itemLastModifiedDate;
    }
    public String getitemLastModifiedByUser(){
        return itemLastModifiedByUser;
    }
    public void setItemLastModifiedByUser(String itemLastModifiedByUser){
        this.itemLastModifiedByUser=itemLastModifiedByUser;
    }
    public itemStatus getItemStatus(){
      return itemStatus;
    }
    public void setItemStatus(ItemStatus itemStatus){
        this.itemStatus=itemStatus;
    }
    public enum ItemStatus{
        AVAILABLE,SOLD
    }
}
