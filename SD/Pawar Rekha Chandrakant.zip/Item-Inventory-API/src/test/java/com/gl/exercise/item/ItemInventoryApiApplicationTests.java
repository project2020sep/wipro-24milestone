package com.gl.exercise.item;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.gl.exercise.item.beans.Item;
import com.gl.exercise.item.repo.ItemRepo;
import com.gl.exercise.item.service.ItemService;

@SpringBootTest
class ItemInventoryApiApplicationTests {

	@Mock
    private ItemRepo itemRepo;
	
	@InjectMocks
    private ItemService itemService;
	
	private List<Item> mockItems;
	
	@BeforeEach
    public void setup() {
        // Initialize mock data
		mockItems = new ArrayList<>();
		mockItems.add(new Item(1, "item 1", "user 1", LocalDate.of(2024, 8, 2), 100, 120, LocalDate.of(2024, 8, 3), "user 1", "available"));
		mockItems.add(new Item(2, "item 2", "user 1", LocalDate.of(2024, 8, 2), 100, 120, LocalDate.of(2024, 8, 3), "user 1", "available"));
		mockItems.add(new Item(3, "item 3", "user 2", LocalDate.of(2024, 8, 2), 100, 120, LocalDate.of(2024, 8, 3), "user 1", "available"));
		mockItems.add(new Item(4, "item 4", "user 2", LocalDate.of(2024, 8, 2), 100, 120, LocalDate.of(2024, 8, 3), "user 1", "available"));
		mockItems.add(new Item(5, "item 5", "user 1", LocalDate.of(2024, 8, 2), 100, 120, LocalDate.of(2024, 8, 3), "user 1", "available"));
		mockItems.add(new Item(6, "item 6", "user 2", LocalDate.of(2024, 8, 2), 100, 120, LocalDate.of(2024, 8, 3), "user 1", "available"));

    }
	
	@Test
    public void testGetById() {
		int id = 1;
        Item target = new Item(1, "item 1", "user 1", LocalDate.of(2024, 8, 2), 100, 120, LocalDate.of(2024, 8, 3), "user 1", "available");

        when(itemRepo.findById(id)).thenReturn(Optional.of(target));
        Item item = itemService.getById(id);
        assertEquals("item 1", item.getItemName());
        verify(itemRepo, times(1)).findById(id);
    }
	
	@Test
    public void testAdd() {
        int id = 1;
        Item item = new Item(1, "item 1", "user 1", LocalDate.of(2024, 8, 2), 100, 120, LocalDate.of(2024, 8, 3), "user 1", "available");

        when(itemRepo.save(any(Item.class))).thenReturn(item);

        Item result = itemService.add(item);

        assertNotNull(result);
        assertEquals(id, result.getItemId());
        assertEquals("item 1", result.getItemName());
    }
	
	@Test
    public void testAddError() {
        Item item = new Item(1, "item 1", "user 1", LocalDate.of(2024, 8, 2), 100, 120, LocalDate.of(2024, 8, 3), "user 1", "available");

        when(itemRepo.save(any(Item.class))).thenReturn(item);
        when(itemRepo.findById(1)).thenReturn(Optional.of(item));

        Item result = itemService.add(item);

        assertNull(result);
    }
	
	@Test
    public void testUpdate() {
        int id = 1;
        Item item = new Item(1, "item 1", "user 1", LocalDate.of(2024, 8, 2), 100, 120, LocalDate.of(2024, 8, 3), "user 1", "available");

        when(itemRepo.save(any(Item.class))).thenReturn(item);

        Item result = itemService.add(item);

        assertNotNull(result);
        assertEquals(id, result.getItemId());
        assertEquals("item 1", result.getItemName());
    }
	
	@Test
    public void testGetAll() {

        when(itemRepo.findAll()).thenReturn(mockItems);
        List<Item> items = itemService.getAll();
        
        assertEquals(6, items.size());
        verify(itemRepo, times(1)).findAll();
    }
	
}
