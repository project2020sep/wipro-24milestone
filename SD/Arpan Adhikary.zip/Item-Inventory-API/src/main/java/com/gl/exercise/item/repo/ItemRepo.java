package com.gl.exercise.item.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gl.exercise.item.beans.Item;

import java.util.List;

public interface ItemRepo extends JpaRepository<Item, Integer> {
    List<Item> findByItemStatusAndItemEnteredByUser(String itemStatus, String itemEnteredByUser);
}