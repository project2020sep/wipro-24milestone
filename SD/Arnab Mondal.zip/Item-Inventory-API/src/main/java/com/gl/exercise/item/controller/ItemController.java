package com.gl.exercise.item.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gl.exercise.item.beans.Item;
import com.gl.exercise.item.service.ItemService;

@RestController
@RequestMapping("/app/item")
public class ItemController {
    @Autowired
    private ItemService service ;

    @PostMapping
    public ReponseEntity<item>addItem(@RequestBody Item item){
        try {
            Item savedItem = service.add(item);
            return new ResponseEntity->(savedItem,HttpStatus.CREATED);
        }catch(RuntimeException e){
            return new ResponseEntity->(HttpStatus.BAD_REQUEST);
        }
    
    }

    @PutMapping("/{itemID}")
    public ResponseEntity<item>updateItem(@PathVariable Integer itemId, @RequestBody Item item){
        if(!itemId.equals(item.getItemId())){
            return new ResponseEntity-> (HttpStatus.BAD_REQUEST);
        }
        try{
            Item updatedItem= service.update(item);
            return new ResponseEntity->(updatedItem, HttpStatus.OK);
        }
        catch(RuntimeException e)
        {
            return new ResponseEntity->(HttpStatus.NOT_FOUND);
        }
    }
    @DeleteMapping("/{itemId}")
    public ResponseEntity<Void> deleteItem(@PathVariable Integer itemId) {
        try {
            service.deleteById(itemId);
            return new ResponseEntity->(HttpStatus.OK);
        } catch (RuntimeException e) {
            return new ResponseEntity->(HttpStatus.BAD_REQUEST);
        }
    }

    @DeleteMapping
    public ResponseEntity<Void> deleteAllItems() {
        service.deleteAll();
        return new ResponseEntity->(HttpStatus.OK);
    }

    @GetMapping("/{itemId}")
    public ResponseEntity<Item> getItemById(@PathVariable Integer itemId) {
        try {
            Item item = service.getById(itemId);
            return new ResponseEntity->(item, HttpStatus.OK);
        } catch (RuntimeException e) {
            return new ResponseEntity->(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping
    public ResponseEntity<List<Item>> getAllItems(
            @RequestParam Optional<String> itemStatus,
            @RequestParam Optional<String> itemEnteredByUser,
            @RequestParam Optional<Integer> pageSize,
            @RequestParam Optional<Integer> page,
            @RequestParam Optional<String> sortBy
    ) {
        if (itemStatus.isPresent() && itemEnteredByUser.isPresent()) {
            Item.ItemStatus status = Item.ItemStatus.valueOf(itemStatus.get());
            List<Item> items = service.getByStatusAndItemEnteredByUserName(status, itemEnteredByUser.get());
            return new ResponseEntity->(items, HttpStatus.OK);
        } else if (pageSize.isPresent() && page.isPresent()) {
            String sortByField = sortBy.orElse("itemSellingPrice");
            Page<Item> itemPage = service.getItemsSortedBySellPrice(page.get(), pageSize.get(), sortByField);
            return new ResponseEntity->(itemPage.getContent(), HttpStatus.OK);
        } else {
            List<Item> items = service.getAll();
            return new ResponseEntity->(items, HttpStatus.OK);
        }
    }

		
}
