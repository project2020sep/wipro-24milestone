package com.gl.exercise.item.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gl.exercise.item.beans.Item;
import com.gl.exercise.item.service.ItemService;

@RestController
@RequestMapping("/app/item")
public class ItemController {
    @Autowired
    private ItemService itemService;
    @PostMapping
    public ResponseEntity<Item> createItem(@RequestBody Item item){
        Optional<Item> existingItem= itemService.getItemById(item.getItemId());
        if(itemService.getItemById(item.gerItemId()).isPresent()){
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
                
            
        }
        item savedItem= itemService.savedItem(item);
        return new ResponseEntity<>(savedItem,HttpStatus.CREATED);
    }
    @PutMapping("/{itemId}") 
    public ResponseEntity<Item> updateItem(@PathVariable Long itemId,@RequestBody Item item)
    {
        Optional<Item> existingItem=itemService.getItemById(itemId);
        if(existingItem.isPresent()){
            item.setItemId(itemId);
            Item updatedItem= itemService.saveItem(item);
            return new ResponseEntity<>(updatedItem,HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
    @DeleteMapping("/{ItemId}")
    public ResponseEntity<void> deleteItem(@PathVariable Integer itemId){
        if(!itemService.getItemById(itemId).isPresent()){
            return ResponseEntity.status(400).build();
            
        }
        ItemService.deleteItem(itemId);
        return ResponseEntity.ok().build();
    }
    @DeleteMapping
    public ResponseEntity<void> deleteAllItems(){
        itemService.deleteAllItems();
        return ResponseEntity.ok().build();
    }
    @GetMapping("/{itemId}")
    public ResponseEntity<Item> getItemById(@PathVariable Integer itemId)  {
        Optional<Item> item=itemService.getItemById(itemId);
        if(!item.isPresent()){
            return ResponseEntity.status(404).build();
        }
        return ResponseEntity.ok(item.get());
    }
    @GetMapping
    public ResponseEntity<List<Item>> getAllItems(){
        List<Item> items=itemService.getAllItems();
        return ResponseEntity.ok(items);
    }


		
}
