package com.gl.exercise.item.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.gl.exercise.item.beans.Item;
import com.gl.exercise.item.repo.ItemRepo;

@Service
public class ItemService {

	@Autowired
	ItemRepo repo;
	
	public Item add(Item item) {
		item.setItemEnteredDate(LocalDateTime.now());
		item.setItemLastModifiedDate(LocalDateTime.now());
		return itemRepository.save(item);
	}
	
	public Item updateItem(Integer ItemId, item) {
		Optional<Item> existingItemOptional = itemRepository. findById(itemId);
		if (existingItemOptional.isPresent()){
			Item existingItem = existingItemOptional.get();
			item.setItemId(existingItem.getItemId());
			item.setItemEnteredDate(existingItem.getItemEnteredDate());
			item.setItemLastModifiedDate(LocalDateTime.now());
			return itemRepository.save(item);
		} else{
				return null;

		}
	}
	
	public Item getItemById(Integer itemId) {
		return itemRepository.findById(itemId).orElse(null);
	}
	
	public boolean deleteItem(Integer itemId) {
		if(itemRepository.existsById(itemID)){
			itemRepository.deleteById(itemId);
			return true;
		} else {
			return false;
		}
	}
	public void deleteAllItems() {
		itemRepository.deleteAll();	
	}
	public List<Item> getAllItems() {
		reurn itemRepository.findAll();
	}
	public Page<Item> getItemsWithPagintion(int pageSize, int page, String sortBy) {
		Pageable pageable = PageRequest.of(page, pageSize,Sort.by(sortby));
		return itemRepository.findAll(pageable).getContent(;)
    }
	
	public List<Item> getItemsByStatusAndUser(ItemStatus status, String enteredByUser) {
		return itemRepository.findByItemStatusAndItemEnteredByUser(status, enteredByUser);
        
    }
	
}
