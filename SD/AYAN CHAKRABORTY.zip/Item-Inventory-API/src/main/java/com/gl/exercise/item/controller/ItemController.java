package com.gl.exercise.item.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.gl.exercise.item.beans.Item;
import com.gl.exercise.item.service.ItemService;

@RestController
@RequestMapping("/app/item")
public class ItemController {

    @Autowired
    ItemService itemService;

    @PostMapping
    public ResponseEntity<Item> addItem(@RequestBody Item item) {
        if (itemService.getById(item.getItemId()).isPresent()) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
        Item savedItem = itemService.add(item);
        return new ResponseEntity<>(savedItem, HttpStatus.CREATED);
    }

    @PutMapping("/{itemId}")
    public ResponseEntity<Item> updateItem(@PathVariable int itemId, @RequestBody Item item) {
        if (!itemService.getById(itemId).isPresent()) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        item.setItemId(itemId);
        Item updatedItem = itemService.update(item);
        return new ResponseEntity<>(updatedItem, HttpStatus.OK);
    }

    @DeleteMapping("/{itemId}")
    public ResponseEntity<Void> deleteItem(@PathVariable int itemId) {
        if (!itemService.getById(itemId).isPresent()) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
        itemService.deleteById(itemId);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @DeleteMapping
    public ResponseEntity<Void> deleteAllItems() {
        itemService.deleteAll();
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @GetMapping("/{itemId}")
    public ResponseEntity<Item> getItemById(@PathVariable int itemId) {
        Optional<Item> item = itemService.getById(itemId);
        return item.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
                   .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @GetMapping
    public ResponseEntity<List<Item>> getAllItems() {
        List<Item> items = itemService.getAll();
        return new ResponseEntity<>(items, HttpStatus.OK);
    }

    @GetMapping(params = {"itemStatus", "itemEnteredByUser"})
    public ResponseEntity<List<Item>> getItemsByStatusAndUser(@RequestParam String itemStatus, @RequestParam String itemEnteredByUser) {
        List<Item> items = itemService.getByStatusAndItemEnteredByUserName(itemStatus, itemEnteredByUser);
        return new ResponseEntity<>(items, HttpStatus.OK);
    }

    @GetMapping(params = {"pageSize", "page", "sortBy"})
    public ResponseEntity<List<Item>> getItemsWithPagination(@RequestParam int pageSize, @RequestParam int page, @RequestParam String sortBy) {
        List<Item> items = itemService.getItemsSortedBySellPrice(page, pageSize, sortBy).getContent();
        return new ResponseEntity<>(items, HttpStatus.OK);
    }
}