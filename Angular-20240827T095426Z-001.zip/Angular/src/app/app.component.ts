import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  onFilter(onFilter: any) {
    throw new Error('Method not implemented.');
  }
  ngOnInit() {
    throw new Error('Method not implemented.');
  }
  title = 'PropertListing';
}
