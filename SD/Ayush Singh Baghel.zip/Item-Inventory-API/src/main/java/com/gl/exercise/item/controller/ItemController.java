package com.gl.exercise.item.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gl.exercise.item.beans.Item;
import com.gl.exercise.item.service.ItemService;

@RestController
@RequestMapping("/app/item")
public class ItemController {

        private ItemService itemService;

        public ResponseEntity<Item> addItem(Item item) {
                if (item.getItemId() != null && itemService.getItemById(item.getItemId()) != null){
                    return ResponseEntity.status(400).build();
                }
                Item createdItem = itemService.addItem(item);
                return ResponseEntity.status(201).body(createdItem);
        }

        public ResponseEntity<Item> updateItem(Integer itemId, Item item){

            Item updatedItem = itemService.updateItem(itemId, item);
            if (updatedItem != null) {
                return ResponseEntity.ok(updatedItem);
            } else {
                return ResponseEntity.status(404).build();
                }
            }
            
            public ResponseEntity<Void> deleteItem(Integer ItemId){
                if (itemService.deleteItem(itemId)){
                    return ResponseEntity.ok().build();
                } else {
                    return ResponseEntity.status(400).build();
                    
                }
            }
            
            public ResponseEntity<Item> getItemById(Integer itemId){
                Item item = itemService.getItemById(itemId);
                if (item != null) {
                    return ResponseEntity.ok(item);
        
                } else {
                    return ResponseEntity.status(404).build();
                }
            }

            public ResponseEntity<List<Item>> getAllItems(){
                return ResponseEntity.ok(itemService.getAllItems());

            }

            public ResponseEntity<List<Item>> getItemsByStatusAndUser(ItemStatus itemStatus, String itemEnteredByUser){
                return ResponseEntity.ok(itemService.getItemsByStatusAndUser(itemStatus, itemEnteredByUser));

            }

            public ResponseEntity<List<Item>> getItemsWithPagintion(int pageSize, int page, String sortBy) {
                return ResponseEntity.ok(itemService.getItemsWithPagintion(pagSize,page,sortBy));
            }
        }
		
