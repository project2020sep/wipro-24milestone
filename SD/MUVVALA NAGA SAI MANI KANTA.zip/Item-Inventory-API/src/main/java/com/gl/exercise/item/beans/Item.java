package com.gl.exercise.item.beans;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Item {
@Id
@GeneratedValue(stratgey=GenerationType.IDENTITY)
private int itemId;
private String itemName;
private String itemEnteredByUser;
private LocalDateTime itemEnteredDate;
private double itemBuyingPrice;
private double itemSellingPrice;
private LocalDateTime itemLastModifiedDate;
private String itemLastModifiedByUser;
private ItemStatus ItemStatus;


void setItemId(int itemId){
    this.itemId=itemId;
}
int getItemId(){
    return itemId;
}
void setitemName(String itemName){
    this.itemName=itemName;
}
String getItemName(){
    return itemName;
}	
void setItemEnteredByUser(String itemEnteredByUser){
    this.itemEnteredByUser=itemEnteredByUser;
}
String getItemEnteredByUser(){
    return itemEnteredByUser;
}	
void setItemEnteredDate(LocalDateTime itemEnteredDate){
    this.itemEnteredDate=itemEnteredDate;
}
LocalDateTime getItemEnteredDate(){
    return itemEnteredDate;
}
void setItemBuyingPrice(double itemBuyingPrice){
    this.itemBuyingPrice=itemBuyingPrice;
}
double getItemBuyingPrice(){
    return itemBuyingPrice;
}
void setItemSellingPrice(double itemSellingPrice){
    this.itemSellingPrice=itemSellingPrice;
}
double getItemSellingPrice(){
    return itemSellingPrice;
}
void setItemLastModifiedDate(LocalDateTime itemLastModifiedDate){
    this.itemLastModifiedDate=itemLastModifiedDate;
}
LocalDateTime getItemLastModifiedDate(){
    return itemLastModifiedDate;
}
void setItemLastModifiedByUser(String itemLastModifiedByUser){
    this.itemLastModifiedByUser=itemLastModifiedByUser;
}
String getItemLastModifiedByUser(){
    return itemLastModifiedByUser;
}
void setItemStatus(ItemStatus ItemStatus){
    this.ItemStatus=ItemStatus;
}
ItemStatus getItemStatus(){
    return ItemStatus;
}
}
public enum ItemStatus{
    AVAILABLE, SOLD
}
