package com.gl.exercise.item.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.gl.exercise.item.beans.Item;
import com.gl.exercise.item.service.ItemService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/app/item")
public class ItemController {

    @Autowired
    private ItemService itemService;

    @PostMapping
    public ResponseEntity<Item> addItem(@RequestBody Item item) {
        Optional<Item> existingItem = itemService.getById(item.getItemId());
        if (existingItem.isPresent()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
        Item savedItem = itemService.add(item);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedItem);
    }

    @PutMapping("/{itemId}")
    public ResponseEntity<Item> updateItem(@PathVariable int itemId, @RequestBody Item item) {
        Optional<Item> existingItem = itemService.getById(itemId);
        if (existingItem.isPresent()) {
            Item updatedItem = itemService.update(item);
            return ResponseEntity.ok(updatedItem);
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
    }

    @DeleteMapping("/{itemId}")
    public ResponseEntity<Void> deleteItemById(@PathVariable int itemId) {
        Optional<Item> existingItem = itemService.getById(itemId);
        if (existingItem.isPresent()) {
            itemService.deleteById(itemId);
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
    }

    @DeleteMapping
    public ResponseEntity<Void> deleteAllItems() {
        itemService.deleteAll();
        return ResponseEntity.ok().build();
    }

    @GetMapping("/{itemId}")
    public ResponseEntity<Item> getItemById(@PathVariable int itemId) {
        Optional<Item> item = itemService.getById(itemId);
        return item.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).build());
    }

    @GetMapping
    public ResponseEntity<List<Item>> getAllItems() {
        List<Item> items = itemService.getAll();
        return ResponseEntity.ok(items);
    }

    @GetMapping(params = {"itemStatus", "itemEnteredByUser"})
    public ResponseEntity<List<Item>> getItemsByStatusAndUser(@RequestParam String itemStatus, @RequestParam String itemEnteredByUser) {
        List<Item> items = itemService.getByStatusAndItemEnteredByUserName(itemStatus, itemEnteredByUser);
        return ResponseEntity.ok(items);
    }

    @GetMapping(params = {"pageSize", "page", "sortBy"})
    public ResponseEntity<Page<Item>> getItemsPagedAndSorted(@RequestParam int pageSize, @RequestParam int page, @RequestParam String sortBy) {
        Page<Item> itemsPage = itemService.getItemPagedAndSorted(page, pageSize, sortBy);
        return ResponseEntity.ok(itemsPage);
    }
}

