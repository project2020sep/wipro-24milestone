package com.gl.exercise.item.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gl.exercise.item.beans.Item;
import com.gl.exercise.item.service.ItemService;

@RestController
@RequestMapping("/app/item")
public class ItemController {
      @Autowired
    private ItemService itemService;

    @PostMapping
    public ResponseEntity<Item> addItem(@RequestBody Item item) {
        if (item.getItemId() != null && itemService.getItemById(item.getItemId()).isPresent()) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
        return new ResponseEntity<>(itemService.addItem(item), HttpStatus.CREATED);
    }

    @PutMapping("/{itemId}")
    public ResponseEntity<Item> updateItem(@PathVariable Long itemId, @RequestBody Item itemDetails) {
        Optional<Item> updatedItem = itemService.updateItem(itemId, itemDetails);
        return updatedItem.map(item -> new ResponseEntity<>(item, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @DeleteMapping("/{itemId}")
    public ResponseEntity<Void> deleteItem(@PathVariable Long itemId) {
        if (itemService.deleteItem(itemId)) {
            return new ResponseEntity<>(HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    }

    @DeleteMapping
    public ResponseEntity<Void> deleteAllItems() {
        itemService.deleteAllItems();
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @GetMapping("/{itemId}")
    public ResponseEntity<Item> getItemById(@PathVariable Long itemId) {
        Optional<Item> item = itemService.getItemById(itemId);
        return item.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @GetMapping
    public ResponseEntity<List<Item>> getAllItems() {
        return new ResponseEntity<>(itemService.getAllItems(), HttpStatus.OK);
    }

    @GetMapping(params = {"itemStatus", "itemEnteredByUser"})
    public ResponseEntity<List<Item>> getItemsByStatusAndEnteredByUser(@RequestParam Item.ItemStatus itemStatus,
                                                                       @RequestParam String itemEnteredByUser) {
        return new ResponseEntity<>(itemService.getItemsByStatusAndEnteredByUser(itemStatus, itemEnteredByUser), HttpStatus.OK);
    }

    @GetMapping(params = {"pageSize", "page", "sortBy"})
    public ResponseEntity<List<Item>> getItemsPaginated(@RequestParam int pageSize,
                                                        @RequestParam int page,
                                                        @RequestParam String sortBy) {
        return new ResponseEntity<>(itemService.getItemsPaginated(pageSize, page, sortBy), HttpStatus.OK);
    }
}