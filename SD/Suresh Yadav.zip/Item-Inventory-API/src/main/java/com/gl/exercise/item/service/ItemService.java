Public class itemService {
	@Autowired
	private ItemRepository ItemRepository;

	public item saveItem(Item item) {
		if(ItemRepository.exi stsByid(item.gentlemId()))
		{
			throw new illegalArgumentExecption("Item ID already exist");

		}
	item.setlItemEnteredDte(LocalID ateTime.now());
	item.setlItemLastModifiedDate(LocalDateTime.now());
	return
	
	ItemRepository.Save(item);
	}
public item updateItem(integer itemId, item item) {
	if( 1 itemRepository.existByid(itemid)) {
		throw new illegation illegalArgumentExecption("item ID does not exist");

	}
}item.setlemId(itemId);
item.setlitemLastModifiedDate(LocalDateTime());
return
itemRepository.save(item);

}
public void deleteItem(integer itemId) {
	if(! itemRepository.existByid(itemid)) {
		throw new illegalArgumentExecption("item Id does not exist");
	}
itemRepository.deleteById(itemid);
	
}
public void deleteAllItems() {
	itemRepository.deleteAll();
}
public item gentelById(integer itemid) {
return itemReposiyory.findByid(itemid).orElseThrow(()->new illegalArgumentExecption("Item  ID does not exist"));

public List<Item>getALLItems() {
	return itemRepository.findall();
}
public List<Item> getItemByStatusAndUser(String itemStatus, String itemEnteredByUser)
// add more methods as required
}
}