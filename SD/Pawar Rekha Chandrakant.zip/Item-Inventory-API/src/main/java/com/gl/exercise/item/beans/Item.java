package com.gl.exercise.item.beans;

import java.time.LocalDate;
import java.time.LocalDateTime;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;

@Entity
public class Item {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long itemId;
    private String itemName;
    private String itemEnteredByUser;
    private LocalDateTime itemEnteredDate;
    private Double itemBuyingPrice;
    private Double  itemSellingPrice;
	private LocalDateTime itemLastModifiedDate;
	private String itemLastModifiedByUser;

    @Enumerated(EnumType.STRING)
    private ItemStatus itemStatus;

    public Long getItemId() {
        return itemId;
    }

    public void setItemId(Long itemId){
        this.itemId = itemId;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName){
        this.itemName = itemName;
    }

    public String getItemEnteredByUsser() {
        return itemEnteredByUser;
    }

    public void setItemEnteredByUser(String itemEnteredByUser){
        this.itemEnteredByUser = itemEnteredByUser;
    }

     private LocalDateTime getItemEnteredDate(){
        return itemEnteredDate;
     }

     public void setItemEnteredDate(LocalDateTime itemEnteredDate){
        this.itemEnteredDate = itemEnteredDate;
    }


    private Double getItemBuyingPrice(){
        return itemBuyingPrice;
    }

    public void setItemBuyingPrice(Double itemBuyingPrice){
        this.itemBuyingPrice = itemBuyingPrice;
    }


    private Double  getItemSellingPrice(){
        return itemSellingPrice;
    }

    public void  setItemSellingPrice(Double itemSellingPrice ){
         this.itemSellingPrice= itemSellingPrice;
    }


	private LocalDateTime getItemLastModifiedDate(){
        return itemLastModifiedDate;
    }

    public void setItemLastModifiedDate(LocalDateTime itemLastModifiedDate ){
        this.itemLastModifiedDate=itemLastModifiedDate;
    }

	private String getItemLastModifiedByUser(){
       return itemLastModifiedByUser;
    }

    public void  setItemLastModifiedByUser(String itemLastModifiedByUser){
          this.itemLastModifiedByUser = itemLastModifiedByUser;
    }

    public ItemStatus getItemStatus(){
        return itemStatus;
    }

    public void setItemStatus(ItemStatus itemStatus){
        this.itemStatus=itemStatus;
    }



}
