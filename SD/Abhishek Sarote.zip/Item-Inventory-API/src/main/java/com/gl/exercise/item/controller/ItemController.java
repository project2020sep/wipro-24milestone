package com.gl.exercise.item.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gl.exercise.item.beans.Item;
import com.gl.exercise.item.service.ItemService;


@RestController
@RequestMapping("/app/item")
public class ItemController {

    @Autowired
    private ItemService itemService;

    @PostMapping
    public ResponseEntity<Item> createItem(@RequestBody Item item) {
        Optional<Item> existingItem = itemService.getItemById(item.getItemId());
        if (existingItem.isPresent()) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
        Item savedItem = itemService.saveItem(item);
        return new ResponseEntity<>(savedItem, HttpStatus.CREATED);
    }

    @PutMapping("/{itemId}")
    public ResponseEntity<Item> updateItem(@PathVariable Integer itemId, @RequestBody Item item) {
        Optional<Item> existingItem = itemService.getItemById(itemId);
        if (!existingItem.isPresent()) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        item.setItemId(itemId);
        Item updatedItem = itemService.saveItem(item);
        return new ResponseEntity<>(updatedItem, HttpStatus.OK);
    }

    @DeleteMapping("/{itemId}")
    public ResponseEntity<Void> deleteItem(@PathVariable Integer itemId) {
        Optional<Item> existingItem = itemService.getItemById(itemId);
        if (!existingItem.isPresent()) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
        itemService.deleteItemById(itemId);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @DeleteMapping
    public ResponseEntity<Void> deleteAllItems() {
        itemService.deleteAllItems();
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @GetMapping("/{itemId}")
    public ResponseEntity<Item> getItemById(@PathVariable Integer itemId) {
        Optional<Item> existingItem = itemService.getItemById(itemId);
        if (!existingItem.isPresent()) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(existingItem.get(), HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<List<Item>> getAllItems() {
        List<Item> items = itemService.getAllItems();
        return new ResponseEntity<>(items, HttpStatus.OK);
    }

    @GetMapping(params = {"itemStatus", "itemEnteredByUser"})
    public ResponseEntity<List<Item>> getItemsByStatusAndUser(@RequestParam Item.Status itemStatus,
                                                              @RequestParam String itemEnteredByUser) {
        List<Item> items = itemService.getItemsByStatusAndUser(itemStatus, itemEnteredByUser);
        return new ResponseEntity<>(items, HttpStatus.OK);
    }

    @GetMapping(params = {"pageSize", "page", "sortBy"})
    public ResponseEntity<List<Item>> getItemsByPage(@RequestParam int pageSize,
                                                     @RequestParam int page,
                                                     @RequestParam String sortBy) {
        List<Item> items = itemService.getItemsByPage(pageSize, page, sortBy);
        return new ResponseEntity<>(items, HttpStatus.OK);
    }
}