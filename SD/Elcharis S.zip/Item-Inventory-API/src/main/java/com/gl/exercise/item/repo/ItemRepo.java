package com.gl.exercise.item.repo;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.gl.exercise.item.beans.Item;

public interface ItemRepo extends JpaRepository<Item, Integer> {

    Page<item> findByItemStatusAnditemEnteredByUser(String itemstatus, String itemEnteredByUser, Pageable pageable);
}
