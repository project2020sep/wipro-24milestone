package com.gl.exercise.item.controller;

import java.util.Optional;
import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestParam;

import com.gl.exercise.item.beans.Item;
import com.gl.exercise.item.service.ItemService;

@RestController
@RequestMapping("/app/item")
public class ItemController {
 @Autowired
 private ItemService itemService;

 @PostMapping
 public ResponseEntity<Item>
 createItem(@RequestBody Item item){
    if
    (itemService.getById(item.getItemId()).isPresent()){
        return ResponseEntity.status(400).build();
    }
    Item createItem = itemService.createItem(item);
    return ResponseEntity.status(201).body(createItem);

    
 }
 @PutMapping("/{itemId}")
 public ResponseEntity<Item> updateItem(@PathVariable Integer itemId, @RequestBody Item item){
    Optional<Item> updatedItem = itemService.updateItem(itemId, item);
    return updatedItem.map(ResponseEntity::ok).orElseGet(()-> ResponseEntity.status(404).build());
 }

 @DeleteMapping("/{itemId}")
 public ResponseEntity<Void> deleteItemById(@PathVariable Integer itemId){
    if(itemService.getById(itemId).isPresent()){
        itemService.deleteItemById(itemId);
        return ResponseEntity.ok().build();
    }
    return ResponseEntity.status(400).build();
 }

 @DeleteMapping
 public ResponseEntity<Void> deleteAllItems(){
    itemService.deleteAll();
    return ResponseEntity.ok().build();
 }

 @GetMapping("/{itemId}")
 public ResponseEntity<Item> getItemById(@PathVariable Integer itemId){
    return itemService.getById(itemId).map(ResponseEntity::ok).orElseGet(()-> ResponseEntity.status(404).build());
 }
 @GetMapping
	public ResponseEntity<List<Item>> getAllItems(){
    
    return ResponseEntity.ok(itemService.getAll());
 }	


// @GetMapping(params = {"pageSize","page","sortBy"})
// public ResponseEntity<List<Item>> getItemWithPageinationAndSorting(@RequestParam int pageSize, @RequestParam int page, @RequestParam String sortBy){
  //  return ResponseEntity.ok(itemService.getItemWithPageinationAndSorting(pageSize, page, sortBy));
 //}
}
