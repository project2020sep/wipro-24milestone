package com.gl.exercise.item.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gl.exercise.item.beans.Item;
import com.gl.exercise.item.service.ItemService;

@RestController
@RequestMapping("/app/item")
public class ItemController {

    @Autowired
    private ItemService itemService;
	
    @PostMapping
    public ResponseEntity<Item> addItem(@RequestBody Item item){
        Optional<Item> existingItem = itemService.getById(item.getItemId());
        if(existingItem.isPresent()){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
        Item savedItem = itemService.add(item);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedItem);
    }

    @PutMapping("/{itemId}")
    public ResponseEntity<Item> updateItem(@PathVariable int itemId, @RequestBody Item item){
        Optional<Item> existingItem = itemService.getById(itemId);
        if(existingItem.isPresent()){
            Item updatedItem = itemService.update(item);
            return ResponseEntity.ok(updatedItem);
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
    }

    @DeleteMapping("/{itemId}")
    public ResponseEntity<Void> deleteItemById(@PathVariable int itemId){
        Optional<Item> existingItem = itemService.getById(itemId);
        if(existingItem.isPresent()){
            itemService.deleteById(itemId);
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
    }

    @DeleteMapping
    public ResponseEntity<Void> deleteAllItems(){
        itemService.deleteAll();
        return ResponseEntity.ok().build();
    }

    @GetMapping("/{itemId}")
    public ResponseEntity<Item> getItemById(@PathVariable int itemId){
        Optional<Item> item = item.Service.getById(itemId);
        return item.map(ResponseEntity::ok).orElse(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).build());
    }

    @GetMapping
    public ResponseEntity<List<Item>> getAllItem(){
        List<Item> items = itemService.getAll();
        return ResponseEntity.ok(items);
    }

    @GetMapping(params = {"itemStatus","itemEnteredByUser"})
    public ResponseEntity<List<Item>> getItemsByStatusAndUser(@RequestParam String itemStatus, @RequestParam String itemEnteredByUser){
        List<Item> items = itemService.getByStatusAndItemEnteredByUserName(itemStatus,itemEnteredByUser);
        return ResponseEntity.ok(items);
    }


    @GetMapping(params = {"pageSize","pagesortBy"})
    public ResponseEntity<List<Item>> getItemsPagedAndSorted(@RequestParam int pageSize, @RequestParam int page, @RequestParam String sortBy){
        Page<Item> itemPage = itemService.getItemsPagedAndSorted(page,pageSize,sortBy);
        return ResponseEntity.ok(itemsPage);
    }

}
