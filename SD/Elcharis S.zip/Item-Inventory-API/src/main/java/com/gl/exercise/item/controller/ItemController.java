package com.gl.exercise.item.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;


import com.gl.exercise.item.beans.Item;
import com.gl.exercise.item.service.ItemService;

@RestController
@RequestMapping("/app/item")
public class ItemController {

    @Autowired
    private ItemService itemservice;

    @PostMapping
    public ResponseEntity<Item> addItem(@RequestBody Item item) {
        Optional<Item> existingItem = itemService.getItemById(item.getItemById());
        if(existingItem.isPresent()){
            return new ResponseEntity<>(HttpStatus.Bad_REQUEST);
        }
        Item savedItem = itemService.saveItem(item);
        return new ResponseEntity<>(savedItem, HttpStatus.CREATED);
    }

    @PutMapping("/{itemId}")
    public ResponseEntity<Item> updateItem(@PathVariable int itemId, @RequestBody Item item){
        if(!itemService.getItemById(itemId).isPresent()){
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        item.setItemId(itemId);
        Item updatedItem = itemService.savedItem(item);
        return new ResponseEntity<>(updatedItem, HttpStatus.OK);
    }

    @DeleteMapping("/{itemid}")
    public ResponseEntity<Void> deleteItem(@PathVariable int itemId) {
        if(!itemService.getItemById(itemId).isPresent()){
            return new ResponseEntity<>(HttpStatus.Bad_REQUEST);
        }
        itemService.deleteId(itemId);
        return new ResponseEntity<>(HttpStatus.OK);

    @DeleteMapping
    public ResponseEntity<Void> deleteAllItems(){
        itemService.deleteAllItems();
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @GetMapping("/{itemId}")
    public ResponseEntity<Item> getItemById(@PathVariable int itemId) {
        Optional<Item> item = itemService.getItemById(itemId);
        if(item.isPresent()){
            return new RequestEntity<>(item.get(), HttpStatus.OK);
        }
        return new RequestEntity<>(HttpStatus.NOT_FOUND)
    }

    @GetMapping
    public ResponseEntity<Page<Item>> getAllItems(@RequestParam(value ="ItemStatus", required =false) String itemStatus, @RequestParam(value ="itemEnteredByUser", required = false) String itemEnteredByUser, Pageable pageable) {
        if(itemStatus !=null && itemEnteredByUser !=null){
            return new RequestEntity<>(itemservice.getByStatusAndItemEnteredBy(itemStatus, itemEnteredByUser, pageable), HttpStatus.OK);
        }
        return new RequestEntity<>(itemService.getAllItems(pageable), HttpStatus.ok);
        }
    }
}
       

