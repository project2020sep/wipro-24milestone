package com.gl.exercise.item.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gl.exercise.item.beans.Item;
import com.gl.exercise.item.service.ItemService;

@RestController
@RequestMapping("/app/item")
public class ItemController {
    @Autowired private ItemService itemService;

    @PostMapping
    public ResponseEntity<Item> createItem(@RequestBody Item item){
        Optional<Item> existingItem= itemService.getById(item.getItemId());
        if(existingItem.isPresent()){
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        } Item addedItem = itemService.add(item);
        return new ResponseEntity<>(addedItem, HttpStatus.CREATED);
    }

    @PutMapping("/{itemId}")
    public ResponseEntity<Item>update(@PathVariable Integer itemId, @RequestBody Item item){
        Item updatedItem = itemService.update(itemId, item);
        if (updatedItem == null){
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(updatedItem, HttpStatus.NOT_FOUND);
    }

    @DeleteMapping
    public ResponseEntity<Void>deleteById(@PathVariable Integer itemId){
        if (itemService.getById(itemId).isPresent()){
            itemService.deleteById(itemId);
            return new ResponseEntity<>(HttpStatus.Ok);
        }
        return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
    }

    @DeleteMapping
    public ResponseEntity<Void> deleteAll(){
        itemService.deleteAll();
        return new ResponseEntity<>(HttpStatus.Ok);
    }
    @GetMapping("/{itemId}")
    public ResponseEntity<Item> getById(@PathVariable Integer itemId){
        Optional<Item> item = itemService.getById(itemId);
        return item.map(ResponseEntity::ok).orElseGet() -> new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @GetMapping
    public ResponseEntity<List<Item>> getAll(
        @RequestParam (value = "itemStatus", required = false) String status,
        @RequestParam(value = "itemEnteredByUser", required= false) String itemEnteredByUser) {
            if (status != null && itemEnteredByUser != null){
                List<Item> items =  itemService.getByStatusAndItemEnteredByUserName(status, itemEnteredByUser);
                return new ResponseEntity<>(items, HttpStatus.Ok);

            }
            List<Item> items = itemService.getAll();
            return new ResponseEntity<>(items, HttpStatus.Ok);
        }

        @GetMapping(param = {"pageSize", "page", "sortBy"})
        public ResponseEntity<List<Item>> getItemsSortedBySellPrice(
            @RequestParam int pageSize,
            @RequestParam int page,
            @RequestParam String sortBy){
                List<Item> items itemService.getItemsSortedBySellPrice(pageSize, page, sortBy);
                return new ResponseEntity<> (items, HttpStatus.Ok);
            }
        

		
}
