package com.gl.exercise.item.repo;

import java.util.List;

import org.springframework.data.domain.Page;
//import org.springframework.data.repository.quer.Param;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.gl.exercise.item.beans.Item;

public interface ItemRepo extends JpaRepository<Item, Integer> {

	/*@Query("Select i from item i where i.status=:status And i.itemEnteredByUseName=:userName")
    public List<Item> getByStatusAndItemEnteredByUserName(@Param("status") String status,@Param("itemEnteredByUser") String itemEnteredByUser) {
    }*/
	
}
