package com.gl.exercise.item.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestParam;

import com.gl.exercise.item.beans.Item;
import com.gl.exercise.item.service.ItemService;

@RestController
@RequestMapping("/app/item")
public class ItemController {

		@Autowired
        private ItemService itemService;

        @PostMapping
        public ResponseEntity<Item> addItem(@RequestBody Item item) {
            try {
                Item createdItem = itemService.add(item);
                return new ResponseEntity<>(createdItem, HttpStatus.CREATED);
            } catch (RuntimeException e) {
                return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
            }
        }

        @PutMapping("/{itemId}")
        public ResponseEntity<Item> updateItem(@PathVariable int itemId, @RequestBody Item item) {
            try {
                item.setItemId(itemId);
                Item updatedItem = itemService.update(item);
                return new ResponseEntity<>(updatedItem, HttpStatus.OK);
            } catch (RuntimeException e) {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }
        }

        @GetMapping("/{itemId}")
        public ResponseEntity<Item> getItemById(@PathVariable int itemId) {
            try {
                Item item = itemService.getById(itemId;)
                
                return new ResponseEntity<>(item, HttpStatus.OK);
            } catch (RuntimeException e) {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }
        }

        @DeleteMapping("/{itemId}")
        public ResponseEntity<Void> deleteItemById(@PathVariable int itemId) {
            try {
                
                itemService.deleteById(itemId);
                return new ResponseEntity<>(HttpStatus.OK);
            } catch (RuntimeException e) {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }
        }

        @DeleteMapping
        public ResponseEntity<Void> deleteAllItems() {
            itemService.deleteAll();
            return new ResponseEntity<>(HttpStatus.OK)
        }

        @GetMapping
        public ResponseEntity<List<Item>> getAllItems() {
            List<Item> items = itemService.getAll();
            return new ResponseEntity<>(items, HttpStatus.OK);
        }

        @GetMapping(params = {"page","pageSize"})
        public ResponseEntity<Page<Item>> getItemsSortedBySellPrice(@RequestParam int page, @RequestParam int pageSize) {
            Page<Item> items = itemService.getItemsSortedBySellingPrice(page,pageSize);
            return new ResponseEntity<>(items, HttpStatus.OK);
        }

        @GetMapping(params = {"status","enteredByUser"})
        public ResponseEntity<List<Item>> getItemsByStatusAndUserName(@RequestParam String status, @RequestParam String enteredByUser) {
            try {
                List<Item> items = itemService.getByStatusAndItemEnteredByUserName(status,enteredByUser);
                return new ResponseEntity<>(items,HttpStatus.OK);

            }
        }
}
