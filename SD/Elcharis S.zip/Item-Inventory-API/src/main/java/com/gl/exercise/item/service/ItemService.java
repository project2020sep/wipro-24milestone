package com.gl.exercise.item.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.dao.DataAccessException;
import org.springframework.data.domain.Page;
//import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
//import org.springframework.data.domain.Sort;
//import org.springframework.stereotype.Service;

import com.gl.exercise.item.beans.Item;
import com.gl.exercise.item.repo.ItemRepo;

@Service
public class ItemService {

	@Autowired
	private ItemRepo repo;

	public Item saveItem(Item item){
	return ItemRepo.saved(item);
	}
	
	public Optional<Item> getItemById( int itemId){
		return itemRepo.findById(itemId);
	}
	public void deleteItem(int itemId){
		item.Repo.deleteById(itemid);
	}
	public void deleteAllItems(){
		item.Repo.deleteAll();
	}

	public Page<Item> getAllItems(Pageable pageable){
		return itemRepo.findAll(pageable);
	}
	
	public Page<item> getByStatusAndItemEnteredBy(String status, String enteredBy, Pageable pageable) {
		return itemRepo.findByItemStatusAnditemEnteredByUser(status, enteredBy,pageable);
	}
/**	public Item add(Item item) {
		return repo.save(item);
	}
	
	public Item update(Item item) {
		return.repo.save(item);
	}
	
	public Item getById(int itemId) {
		return.repo.findById(itemId);
		
	}
	
	public void deleteById(int itemId) {
		repo.deleteById(itemId);
	}
	
	public void deleteAll() {
		repo.deleteAll();
	}
	
	public List<Item> getAll() {
		return repo.findAll();
	}
	
	public Page<Item> getItemsSortedBySellPrice(int page, int pageSize) {
		Pageable pageable = PageRequest.of(page, pageSize.Sort.by("itemSellingPrice").ascending());
        return repo.findAll(pageable);
    }
	
	public List<Item> getByStatusAndItemEnteredByUserName(String status, String itemEnteredByUser) {
        return repo.findByItemStatusAnditemEnteredByUser(status,itemEnteredByUser);
    }
	**/
}
