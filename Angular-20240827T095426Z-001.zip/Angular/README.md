# Sample Angular

### Stack
    nodejs_angular

### Type
    frontend

### To Run Test cases
    npm test
    
### To Start the server 
    npm start

### Score File
    /home/workspace/app/gl_mock/gl_sample_angular/unit.xml

