package com.gl.exercise.item.beans;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Item {
    privateInteger itemID;

    private String itemName;
    private String itemEnteredByUser;
    private LocalDateTime itemEnteredDate;
    private Double itemBuyingPrice;
    private Double itemSellingPrice;
    private LocalDateTime itemLastModifiedDate;
    private String itemLastModifiedByUser;

    private ItemStatus itemStatus;

	
}

enum ItemStatus {
    AVAILABLE,
    SOLD
}