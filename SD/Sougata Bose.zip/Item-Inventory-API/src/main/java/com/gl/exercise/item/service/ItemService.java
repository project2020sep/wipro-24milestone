package com.gl.exercise.item.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.gl.exercise.item.beans.Item;
import com.gl.exercise.item.repo.ItemRepo;

@Service
public class ItemService {

	@Autowired
	ItemRepo repo;
	
@Service
public class ItemService {

    @Autowired
    ItemRepo repo;

    public Item add(Item item) {
        return repo.save(item);
    }

    public Item update(Item item) {
        return repo.save(item);
    }

    public Optional<Item> getById(int itemId) {
        return repo.findById(itemId);
    }

    public void deleteById(int itemId) {
        repo.deleteById(itemId);
    }

    public void deleteAll() {
        repo.deleteAll();
    }

    public List<Item> getAll() {
        return repo.findAll();
    }

    public Page<Item> getItemsSortedBySellPrice(int page, int pageSize, String sortBy) {
        Pageable pageable = PageRequest.of(page, pageSize, Sort.by(sortBy));
        return repo.findAll(pageable);
    }

    public List<Item> getByStatusAndItemEnteredByUserName(String status, String itemEnteredByUser) {
        return repo.findByItemStatusAndItemEnteredByUser(status, itemEnteredByUser);
    }
}





