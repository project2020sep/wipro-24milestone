package com.gl.exercise.item.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gl.exercise.item.beans.Item;
import com.gl.exercise.item.service.ItemService;

@RestController
@RequestMapping("/app/item")
public class ItemController {
    @Autowired
    private ItemService itemService;

    @PostMapping
    public ResponseEntity<?> addItem(@RequestBody Item item){
        if(itemService.getById(item.getItemId()).isPresent()){
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Item Id already exists.");

        }
        Item newItem = itemService.add(item);
        return ResponseEntity.status(HttpStatus.CREATED).body(newItem);
    }
    @PutMapping("/{itemId}")
     public ResponseEntity<?> updateItem(@PathVariable int itemId, @RequestBody Item item){
        item.setItemId(itemid);
        Optional<Item> updatedItem= itemService.update(item);
        if(updatedItem.isPresent()){
            return ResponseEntity.ok(updatedItem.get());

        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Item not found.");

     }
     @DeleteMapping("/{itemId}")
     public ResponseEntity<?> deleteItem(@PathVariable int itemId){
        if(itemService.getById(itemId).isPresent()){
            itemService.deleteById(itemId);
            return ResponseEntity.ok().build();
        }
         return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Item not found.");

     }
     @DeleteMapping
     public ResponseEntity<?> deleteAllItems(){
        itemService.deleteAll();
         return ResponseEntity.ok().build();
     }
     @GetMapping("/{itemId}")
     public ResponseEntity<?> getItem(@PathVariable int itemId){
        Optional<Item> item= itemService.getById(itemId);
        if(item.isPresent()){
            return ResponseEntity.ok(item.get());

        }
       return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Item not found.");
     }
     @GetMapping
     public ResponseEntity<List<Item>> getAllItems(){
        return ResponseEntity.ok(itemService.getAll());
     }
     @GetMapping(params = {"itemStatus", "itemEnteredByUser"})
     public ResponseEntity<List<Item>> getItemsByStatusAndUser(
        @RequestParam ItemStatus itemStatus,
        @RequestParam String itemEnteredByUser) {
            return ResponseEntity.ok(itemService.getByStatusAndItemEnteredByUserName(itemStatus, itemEnteredByUser));

        }
        @GetMapping(params = {"pageSize", "page", "sortBy"})
        public ResponseEntity<List<Item>> getItemsByPageAndSort(
            @RequestParam int pageSize,
            @RequestParam int page,
            @RequestParam String sortBy) {
                return ResponseEntity.ok(itemService.getItemsSortedBySellPrice(page, pageSize));

            }

     
}
