package com.gl.exercise.item.controller;

import java.util.Optional;
import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gl.exercise.item.beans.Item;
import com.gl.exercise.item.service.ItemService;

@RestController
@RequestMapping("/app/item")
public class ItemController {
    @Autowired
    private ItemService itemser;

    @PostMapping("/app/item")
    public Item add(@RequestBody Item item) {
		return itemser.add(item);
	}
	@PostMapping("/app/item/{item}")
	public Item update(@RequestBody Item item) {
		return itemser.update(item);
	}
	@GetMapping("/app/item/{itemId}")
	public Item getById(@PathVariable int itemId) {
		return itemser.getById(itemId);
	}
	@DeleteMapping("/app/item/{itemId}")
	public void deleteById(@PathVariable int itemId) {
		itemser.deleteById(itemId);
	}
	@DeleteMapping("/app/item")
	public void deleteAll() {
		itemser.deleteAll();
	}
	@GetMapping("/app")
	public List<Item> getAll() {
		return itemser.getAll();
	}
	@GetMapping("/app/item?pageSize={pageSize}&page={page}&sortBy={sortByField}")
	public Page<Item> getItemsSortedBySellPrice(@RequestParam int page,@RequestParam int pageSize) {
        Pageable pageable=PageRequest.of(page,pageSize);
        List<item> items=itemService.getItemsSortedBySellPrice(page,pageSize);
		return items;
    }
	@GetMapping(" /app/item?itemStatus={status}&itemEnteredByUser={enteredBy}:")
	public List<Item> getByStatusAndItemEnteredByUserName(@RequestParam String status,@RequestParam String itemEnteredByUser) {
        return itemser.getByStatusAndItemEnteredByUserName(status,itemEnteredByUser);
    }
	

		
}
