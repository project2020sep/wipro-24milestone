package com.gl.exercise.item.repo;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.gl.exercise.item.beans.Item;

public interface ItemRepo extends JpaRepository<Item, Integer> {
    List<Item> findByItemStatusAndItemEnteredByUser(Item.ItemStatus itemStatus , String itemEnteredByUser);
	
    @Query("SELECT  i FROM Item i WHERE i.itemStatus = :itemStatus AND i.itemEnteredByUser = :itemEnteredByUser ")
    List<Item> findByStstusAndEnteredByUser(Item.ItemStatus itemStatus , String itemEnteredByUser);

    Page<Item> findByOrderByItemSellingPrice(Pagable Pageable);
	
}
