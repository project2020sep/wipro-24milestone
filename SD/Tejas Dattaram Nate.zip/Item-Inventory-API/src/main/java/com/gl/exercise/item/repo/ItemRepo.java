package com.gl.exercise.item.repo;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.gl.exercise.item.beans.Item;

public interface ItemRepo extends JpaRepository<Item, Integer> {
List<Item> findByItemStatusAndItemEnteredByUser(String itemStatus, String itemEnteredByUser);
	
	boolean existById(int itemId);
    boolean existByItemStatus(String ItemStatus);
}
