package com.gl.exercise.item.repo;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.gl.exercise.item.beans.Item;
import com.gl.exercise.item.beans.ItemStatus;


public interface ItemRepo extends JpaRepository<Item, Integer> {

    List<Item> findByItemStatusAndItemEnteredByUser( ItemStatus itemStatus, String itemEnteredByUser);
    Page<Item> findAll(Pageable pageable);
	
	
}
